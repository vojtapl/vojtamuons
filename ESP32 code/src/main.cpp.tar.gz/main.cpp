/*
!overflow!
new code from rpi
*/
/*
Commands:
help
print_all_data
print_data_count
restart
*/

#include <Arduino.h>
#include "SD_MMC.h"
#include "FS.h"
#include <EEPROM.h> //save data_count, file_counter, counter //https://github.com/espressif/arduino-esp32/blob/master/libraries/EEPROM/examples/eeprom_write/eeprom_write.ino

#define inputPin 16
#define timeout 24000 // for 100us at 240MHz clock
#define EEPROM_size 4

volatile unsigned long timeA;
volatile unsigned long timeB;
volatile long dTime;
volatile int wasInterrupt = 0;
int file_counter = 0;
int counter = 0;
int new_file_threshold = 2000;
int serial_in_data = 0;
int data_count = 0;

void IRAM_ATTR isr(){
    timeA = ESP.getCycleCount();  // Overflow every ~28s
    wasInterrupt = 1;
}

void writeFile(fs::FS &fs, const char * path, const char * message){
    //Serial.printf("Writing file: %s\n", path);

    File file = fs.open(path, FILE_WRITE);
    if(!file){
        Serial.println("Failed to open file for writing");
        return;
    }
    if(file.print(message)){
        //Serial.println("File written");
    } else {
        Serial.println("Write failed");
    }
}

void appendFile(fs::FS &fs, const char * path, const char * message){
    //Serial.printf("Appending to file: %s\n", path);

    File file = fs.open(path, FILE_APPEND);
    if(!file){
        Serial.println("Failed to open file for appending");
        return;
    }
    if(file.print(message)){
        //Serial.println("Message appended");
    } else {
        Serial.println("Append failed");
    }
}

void readFile(fs::FS &fs, const char * path){
    Serial.printf("Reading file: %s\n", path);

    File file = fs.open(path);
    if(!file){
        Serial.println("Failed to open file for reading");
        return;
    }

    //Serial.print("Read from file: ");
    while(file.available()){
	    Serial.write(file.read());
    }
}

void createDir(fs::FS &fs, const char * path){
    //Serial.printf("Creating Dir: %s\n", path);
    if(fs.mkdir(path)){
        //Serial.println("Dir created");
    }else{
        Serial.println("mkdir failed");
    }
}

void setup(){
    pinMode(inputPin, INPUT);
    attachInterrupt(inputPin, isr, RISING);
    Serial.begin(115200);
    
    if(!SD_MMC.begin()){
        Serial.println("Card Mount Failed");
        return;
    }

    uint8_t cardType = SD_MMC.cardType();
    if(cardType == CARD_NONE){
        Serial.println("No SD card attached");
        return;
    }

    createDir(SD_MMC, "/data");

    EEPROM.begin(EEPROM_size);
    EEPROM.get(0, file_counter);
    EEPROM.get(2, data_count);
    Serial.println("Initialized!");
}

void loop() {
    if(wasInterrupt == 1){
        timeB = timeA;
        timeA = 0;

        while(ESP.getCycleCount() < timeB + timeout){
            if (timeA != 0){
                dTime = timeA - timeB;
                Serial.println(dTime);

                if((SD_MMC.usedBytes() / (1024*1024) > 100)){
                    if(counter == new_file_threshold){
                        file_counter ++;
                        counter = 0;
                    }     

                    String path = "/data/" + String(file_counter) + ".csv";  

                    if(counter == 0){
                        writeFile(SD_MMC, path.c_str(), (String(dTime) + ",").c_str());
                    }else{
                        appendFile(SD_MMC, path.c_str(), (String(dTime) + ",").c_str());
                    }
                    counter ++;
                    data_count ++;
                }else{
                    Serial.print("SD card is full");
                    exit(0);
                }

                EEPROM.write(0, file_counter);
                EEPROM.write(2, data_count);
                EEPROM.commit();                
                wasInterrupt = 0;
                break;
            }
        }
    }
    if(Serial.available()){
        serial_in_data = Serial.read();
        serial_in_data -= 48;
        Serial.print(serial_in_data);
        if(serial_in_data == 1){ //print_data
            Serial.print("Printing data:");
            for(int i = 0; i <= file_counter; i++){
                String open_path = "/data/" + String(i) + ".csv";
                readFile(SD_MMC, open_path.c_str());
            }   
        }else if(serial_in_data == 2){ //print_data_coun
            Serial.print(data_count);
        }else if(serial_in_data == 3){ //restart
            Serial.print("Restarting");
            ESP.restart();
        }else if(serial_in_data == 9){
            Serial.print("counter values reset!"); 
            EEPROM.write(0, 0);
            EEPROM.write(2, 0);
            EEPROM.commit();  
        }else{
            Serial.println("Unknown command");
        }
    serial_in_data = 0;
    }
}
